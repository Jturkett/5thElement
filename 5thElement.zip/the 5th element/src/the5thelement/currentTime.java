package the5thelement;
import java.util.*;

public class currentTime {
	public month currentMonth;
	public day currentDay;
	public time currentTime;
	public month[] year;
	public medsReport medreport;
	public HRreport hrreport;
	public boolean monthChange;
	public String medRepName;
	public String HRRepName;

	public String str1;
	public String str2;
	
	Scanner reader = new Scanner(System.in);

	public currentTime(int startMonth, int startDay, int startTime, ArrayList<medication> meds) {
		str1 = "";
		str2 = "";
		monthChange = false;
		year = new month[12];
		year[0] = new month(31,0);
		year[1] = new month(28,1);
		year[2] = new month(31,2);
		year[3] = new month(30,3);
		year[4] = new month(31,4);
		year[5] = new month(30,5);
		year[6] = new month(31,6);
		year[7] = new month(31,7);
		year[8] = new month(30,8);
		year[9] = new month(31,9);
		year[10] = new month(30,10);
		year[11] = new month(31,11);
		currentMonth = year[startMonth];
		currentDay = currentMonth.get(startDay);
		currentTime = currentDay.get(startTime);
		medreport = new medsReport();
		hrreport = new HRreport();
		for(medication med:meds){
			
			for (int t:med.freqTimeFrame){
				
				for(month m: year){
					
					for (day d:m.days){
						
						d.get(t).addReminder(new reminder(med,t));
						
					}
					
				}
				
			}
			
		}
	}
	
	public void nextTime(){
		int localAvgHR = 0;		//The average heart rate value for the past 3 hours of recorded values in a day
		
		if(currentTime.tVal<95){
			monthChange = false;
			currentTime = currentDay.get(currentTime.tVal+1);
		}
		else if (currentDay.getDOM()<currentMonth.numOfDays()-1){
			monthChange = false;
			if (currentDay.getNumRates()>12){
				
				int totalRate = 0;
				int ratesCounted = 0;
				for (int i=0;ratesCounted<currentDay.getNumRates();i++){
					
					if(currentDay.get(i).getHR()>0){
						
						totalRate+=currentDay.get(i).getHR();
						ratesCounted++;
						
					}
					
				}
				
				currentMonth.setAvgHR(totalRate/currentDay.getNumRates());
				
				
				
			}
			currentDay = currentMonth.get(currentDay.getDOM()+1);
			currentTime = currentDay.get(0);
			
		}
		else if (currentMonth.monthNum()<11){
			monthChange = true;
			str1 = medreport.getReport();
			str2 = hrreport.generateHRReport(currentMonth);
			
			medRepName = "Medicine_report_for_month_"+currentMonth.monthNum();
			HRRepName = "Heart_rate_report_for_month_" + currentMonth.monthNum();
			/*//JsonParser parser1 = new JsonParser();
			//JsonParser parser2 = new JsonParser();
			JsonObject medRep = new JsonObject();
			medRep.addProperty("title", medRepName);
			medRep.addProperty("data", str1);
			
			gson1 = new Gson();
			
			
			JsonObject HRRep = new JsonObject();
			HRRep.addProperty("title", HRRepName);
			HRRep.addProperty("data", str2);
			
			gson2 = new Gson();*/
			
			System.out.println("Monthly reports will be sent to your associated caretakers");
			
			
			
			currentMonth = year[currentMonth.monthNum()+1];
			currentDay = currentMonth.get(0);
			currentTime = currentDay.get(0);
			
			
			
			
		}
		int HR = pullHR();
		currentTime.setHR(HR);
		if(HR>0){
		currentTime.hasRate = true;
		currentDay.numRates = currentDay.numRates+1;
		
		}
		
		if (currentDay.getNumRates()>12){
			int numLeft = 12;
			int totalHR = 0;
			for(int i=currentTime.tVal;numLeft>0;i--){
				
				if (currentDay.get(i).getHR()>0){
					
					totalHR+=currentDay.get(i).getHR();
					numLeft--;
					
				}
				
			}
			localAvgHR = totalHR/currentDay.getNumRates();
			
			if(currentMonth.tookHRMed){
				if(localAvgHR*100>120*currentMonth.avgHR||localAvgHR*100<80*currentMonth.avgHR){
				
					System.out.println("To Patient & Doctor: WARNING: recent heart rate changes detected!");
					
				}
			}
		}
		
		for(reminder r:currentTime.getRem()){
			currentDay.sendRem(r);
			if(r.getTaken()) {
				medreport.addTaken(r,currentTime,currentDay,currentMonth);
			}
			else if(r.getNumDismiss()<12){
				medreport.addDismiss(r, currentTime, currentDay, currentMonth);
			}
			else medreport.addMiss(r, currentTime, currentDay, currentMonth);
			if(r.getMed().isVulnerable&&r.getTaken()) currentMonth.setHRMed();
		}
		
		
		
		
		
	}
	
	public int pullHR(){
		int HR = -1;
		System.out.println("What is the current HR value? (enter -1 if no value given)");
		while (!reader.hasNext()){
		}
			HR = reader.nextInt();
		
		
		
		return HR;
	}
	
	public month[] getYear(){
		
		return year;
		
	}
	
}
