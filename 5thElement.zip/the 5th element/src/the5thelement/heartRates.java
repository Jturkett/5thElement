package the5thelement;

public class heartRates {
	public int tVal;
	public Integer[] rates;
	public heartRates(){
		
		
		
	}
	
	

}
