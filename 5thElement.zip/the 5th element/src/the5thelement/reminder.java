package the5thelement;

import java.util.*;

public class reminder {
	
	public medication medication;
	public int timesDismissed;
	public boolean taken;
	public int tVal;
	
	public reminder(medication med, int t){
		
		medication = med;
		taken = false;
		timesDismissed = 0;
		tVal = t;
		
	}
	
	public medication getMed(){
		return medication;
	}
	public int getNumDismiss(){
		return timesDismissed;
	}
	public int getTVal(){
		return tVal;
	}
	public void setTVal(int t){
		tVal = t;
	}
	public void incrTVal(){
		tVal++;
	}
	public boolean getTaken(){
		return taken;
	}
	public void setTaken(){
		medication.doses = medication.doses-1;
		if(medication.doses<7&&medication.isRefillable){
			System.out.println("You are running low on " + medication.getMedName() + ".  Refill your prescription soon");
		}
		taken=true;
	}
	public void dismiss(){
		timesDismissed++;
	}
	public int sendReminder(){
		String in = null;
		Scanner reader = new Scanner(System.in);
		int output;
		boolean goodInput = false;
		while(!goodInput){
		if(timesDismissed<=10) System.out.println("Reminder: Take " + medication.getMedName() + "   Take | Remind");
		else System.out.println("Reminder: Take " + medication.getMedName()+ "   Take | Dismiss");
		in = reader.next();
		if (in.equals("Take")||in.equals("Remind")||in.equals("Dismiss")||in.equals("take")||in.equals("remind")||in.equals("dismiss")) goodInput=true;
		}
		if(in.equals("Take")||in.equals("take")){
			output= 0;
		}
		else {
			
			output = 1;
			
		}
		return output;
	}

}
