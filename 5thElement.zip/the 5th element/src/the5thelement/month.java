package the5thelement;

public class month {
	
	public int avgHR;
	public int monthnum;
	public day[] days;
	public boolean tookHRMed;
	
	public month(int numDays, int mnum){
		avgHR = -1;
		tookHRMed = false;
		days = new day[numDays];
		monthnum = mnum;
		
		for(int i=0;i<days.length;i++){
			days[i] = new day(i);
		}
		
	}
	public day get(int DayOfMonth){
		
		return days[DayOfMonth];
		
	}
	
	public int numOfDays(){
		
		return days.length;
		
	}
	
	public int monthNum(){
		
		return monthnum;
		
	}
	
	public boolean HRWatch(){
		
		return tookHRMed;
		
	}
	
	public void setHRMed(){
		
		tookHRMed = true;
	}
	
	public void setAvgHR(int avghr){
		
		avgHR = avghr;
		
	}

}
