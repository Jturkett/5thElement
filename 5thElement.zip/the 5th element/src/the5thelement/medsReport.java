package the5thelement;



public class medsReport {

	public String medReport;
	
	public medsReport(){
		
		medReport = "";
		
	}
	
	public String getReport(){
		
		String temp = medReport;
		medReport = "";
		return temp;
		
	}
	
	public void addDismiss(reminder r, time t, day d, month m){
		int minval = t.getMinute();
		String mins = (""+minval);
		if(minval==0) mins="00";
		
		medReport = (medReport + "The reminder to take " + r.getMed().getMedName()+" was postponed at " + t.getHour() + ":" + mins + " on " + (m.monthnum+1) + "/" + (d.getDOM()+1) + "\n");
		
	}
	
	public void addMiss(reminder r, time t, day d, month m){
		int minval = t.getMinute();
		String mins = (""+minval);
		if(minval==0) mins="00";
		medReport = (medReport + "The dosage of " + r.getMed().getMedName()+" was missed at " + t.getHour() + ":" + mins + " on " + (m.monthnum+1) + "/" + (d.getDOM()+1) + "\n");
		
	}
	
	public void addTaken(reminder r, time t, day d, month m){
		int minval = t.getMinute();
		String mins = (""+minval);
		if(minval==0) mins="00";
		
		medReport = (medReport + "The dosage of " + r.getMed().getMedName()+" was taken at " + t.getHour() + ":" + mins + " on " + (m.monthnum+1) + "/" + (d.getDOM()+1) + "\n");
		
		
	}
	
}
