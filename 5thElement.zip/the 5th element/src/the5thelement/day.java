package the5thelement;

public class day {
	
	public time[] times;
	public int dayOfMonth;
	public Integer[] rates;
	public int numRates;
	
	public day(int DOM){
		
		numRates = 0;
		times = new time[96];
		for (int i=0;i<times.length;i++){
			
			times[i] = new time(i);
			dayOfMonth = DOM;
			
		}
		
	}
	
	public int getNumRates(){
		
		return numRates;
		
	}
	
	public void setRates(Integer[] HRInput){
		
		rates = HRInput;
		
	}
	
	public void sendRem(reminder r){
		int reminderSent = r.sendReminder();
		if(reminderSent==0) takeRem(r);
		else{
			dismissRem(r);
		}
		
		//
		
	}
	
	public int getDOM(){
		
		return dayOfMonth;
		
	}
	
	public void dismissRem(reminder r){
		int remTime = r.getTVal();
		r.dismiss();
		if (r.getNumDismiss()<12){
			r.setTVal(r.getTVal()+1);
			times[remTime+1].addReminder(r);
		}
		else{
			
			
		}
		
	}
	
	public void takeRem(reminder r){
		
		r.setTaken();
		
	}
	
	
	
	public time get(int tVal) throws IllegalArgumentException{
		if(tVal>96) throw new IllegalArgumentException("An invalid time was given");
		return times[tVal];
	}
}
