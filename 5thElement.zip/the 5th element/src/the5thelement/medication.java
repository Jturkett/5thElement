package the5thelement;


public class medication {
	public String medName;
	public Boolean isVulnerable;
	public Integer doses;
	public Boolean isRefillable;
	public Integer[] freqTimeFrame;
	public int freqDose;
	public int dosesSkipped; 
	
	public Boolean getRefillable() {
		return isRefillable;
	}
	public void setRefillable(Boolean b) {
		isRefillable = b;
	}
	public Integer getDoses() {
		return doses;
	}
	
	public Boolean getVulnerable () {
		return isVulnerable;
	}
	
	public String getMedName () {
		return medName;
	}
	
	public Integer[] getFreqTimeFrame() {
		return freqTimeFrame;
	}
	
	public Integer getDosesSkipped() {
		return dosesSkipped;
	}
	
	public void incDosesSkipped() {
		dosesSkipped++;
	}
	
	public Integer getDosesLeft() {
		return doses - dosesSkipped;
	}
		
	
	public void setFields (Object[] medInfo) {
		int i = 0;
		medName = (String) medInfo[i++];
		isVulnerable = (Boolean) medInfo[i++];
		doses = (Integer) medInfo[i++];
		isRefillable  = (Boolean) medInfo[i++];
		freqTimeFrame = (Integer[]) medInfo[i++];
	}
}


