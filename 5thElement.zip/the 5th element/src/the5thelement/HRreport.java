package the5thelement;

public class HRreport {

	public String hrreport;
	
	public HRreport(){
		
		hrreport = "";
		
	}
	
	public String generateHRReport(month m){
		
		hrreport = "Heart rate data for month " + m.monthNum() + ":\n";
		
		for(day d:m.days){
			hrreport = hrreport + "day " + d.getDOM() + ":\t";
			for(time t:d.times){
				
				if (!t.hasHR()) hrreport = hrreport + "-,\t";
				else hrreport = hrreport + t.getHR() + ",\t";
				
			}
			hrreport = hrreport + "\n";
			
		}
		
		return hrreport;
		
	}
	
}
