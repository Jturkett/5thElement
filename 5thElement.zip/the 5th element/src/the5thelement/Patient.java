package the5thelement;

import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.IOException;


public class Patient {

public static void main (String[] args) {

ArrayList<medication> meds = new ArrayList<medication>();
		
		//Test code below
		Integer[] vDArray = {32, 48, 64};
		Object[] vulnDepressent = {"SlowBroRX", true, 12, true, vDArray};
		medication vulnDep = new medication();
		vulnDep.setFields(vulnDepressent);
		
		Integer[] placebo = {48};
		Object[] plac = {"Sugar Bombs", false, 6, true, placebo};
		medication place = new medication();
		place.setFields(plac);
		
		Integer[] cold = {40, 82};
		Object[] coldArr = {"Phlegm Destory", false, 5, false, cold};
		medication coldMed = new medication();
		coldMed.setFields(coldArr);
		
		meds.add(vulnDep);
		meds.add(place);
		meds.add(coldMed);
		currentTime mySchedule = new currentTime(0, 30, 80, meds);
		while(true){
		mySchedule.nextTime();
		if(mySchedule.monthChange){
			
			System.out.println(mySchedule.str1);
			
			System.out.println(mySchedule.str2);
			
			/*
			PrintWriter writer1;
			try {
				System.out.println("Hit point 1");
				writer1 = new PrintWriter (new File("medRep.txt"));
				writer1.print(mySchedule.str1);
				writer1.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			PrintWriter writer2;
			try {
				writer2 = new PrintWriter (mySchedule.HRRepName + ".txt");
				writer2.println(mySchedule.str2);
				writer2.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		}
		}

}

}

