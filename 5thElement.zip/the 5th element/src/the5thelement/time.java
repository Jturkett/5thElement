package the5thelement;
import java.util.*;
public class time {

	public int tVal;
	public int hour;
	public int minute;
	public int rate;
	public ArrayList<reminder> rem;
	public boolean hasRate;
	
	
	public time(int timeVal){
		
		tVal = timeVal;
		rate = -1;
		rem = new ArrayList<reminder>();
		
	}
	
	public int getHour(){
		
		return tVal/4;
		
	}
	
	public int getMinute(){
		
		return (tVal%4)*15;
		
	}
	
	public int getHR(){
		
		 return rate;
		
	}
	
	public void setHR(int HR){
		
		rate = HR;
		
	}
	
	public ArrayList<reminder> getRem(){
		return rem;
	}
	
	public void addReminder(reminder r){
		
		rem.add(r);
		
	}
	
	public boolean hasHR(){
		
		if (rate!=-1) return true;
		else return false;
		
	}
	
}
